package lesson1.part3;

public interface Waterfowl {

    void swim();

}
