package lesson1.homework.obstacle;


import lesson1.homework.participant.Participant;

public interface Obstacle {

    boolean passObstacleBy(Participant participant);
}
