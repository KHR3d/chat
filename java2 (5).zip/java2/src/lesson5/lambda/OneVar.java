package lesson5.lambda;

public interface OneVar {
    void start(int a);
}
